function mouseDown(id) {
    console.log(id, ': ', 'down');
    socket.emit('movement', {
        key: id,
        type: 'down'
    })
}

function mouseUp(id) {
    console.log(id, ': ', 'up');
    socket.emit('movement', {
        key: id,
        type: 'up'
    })
}