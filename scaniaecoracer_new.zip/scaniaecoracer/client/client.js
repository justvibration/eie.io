// socket
var socket = io('http://localhost:2000');

var playerId;

socket.on('register', onRegister);

function onRegister (data) {
    playerId = data.id;
    
    socket.emit('accept', {
        id: playerId,
        agent: 'client'
    })
}