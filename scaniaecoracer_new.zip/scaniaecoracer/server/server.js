// dependencies
var express = require('express'),
    app = express(),
    server = require('http').Server(app),
    io = require('socket.io')(server);

// routing
app.get('/', function(req, res) {
    res.sendFile(__dirname + '/index.html');
});
app.use('/', express.static(__dirname + '/'));

// init server
var port = 2000;
server.listen(port, function() {
    console.log('server listens on port: ' + port + '...');
})

// socket io
var SOCKET_LIST = [];
var PLAYER_LIST = [];

io.sockets.on('connection', onConnection);

function onConnection(socket) {
    console.log('player joined the game');
    SOCKET_LIST[socket.id] = socket;

    socket.emit('register', {
        id: socket.id
    });

    socket.on('accept', onAccept);
    socket.on('disconnect', onDisconnect);
    socket.on('movement', onMovement);
};

function onDisconnect(data) {
    console.log('playyer left the game');
}

function onAccept(data) {
    SOCKET_LIST[data.id].agent = data.agent;
}

function onMovement () {
    
}